//here the event starts
module.exports = (client, id, replayedEvents) => {
    console.log(` || <==> || [${String(new Date).split(" ", 5).join(" ")}] || <==> || Shard #${id} Yeniden bağlandı. || <==> ||`)
}
