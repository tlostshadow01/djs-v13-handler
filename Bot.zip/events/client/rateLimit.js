//here the event starts
module.exports = (client, rateLimitData) => {
    console.log(JSON.stringify(rateLimitData).grey.italic.dim);
}

