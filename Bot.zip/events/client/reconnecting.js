//here the event starts
module.exports = client => {
    console.log(`Yeniden bağlanıyor... ${new Date()}.`.bgYellow.black)
}
