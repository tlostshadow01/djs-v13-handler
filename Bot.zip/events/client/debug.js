//here the event starts
module.exports = (client, info) => {
  //console.log(String(info).grey);
}
